import { Module } from '@nestjs/common';

@Module({
  imports: [],
})
export class AuthModule {}
